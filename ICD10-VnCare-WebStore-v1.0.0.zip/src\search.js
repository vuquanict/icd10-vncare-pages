(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }
  root.ICD10Search = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const STOP_WORDS = new Set(["va", "trong", "do", "cua", "voi", "khong"]);

  function normalizeText(value) {
    return String(value || "")
      .toLowerCase()
      .replace(/đ/g, "d")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, " ")
      .trim()
      .replace(/\s+/g, " ");
  }

  function compactText(value) {
    return normalizeText(value).replace(/\s/g, "");
  }

  function makeInitials(value) {
    return normalizeText(value)
      .split(" ")
      .filter((word) => word && !STOP_WORDS.has(word))
      .map((word) => word[0])
      .join("");
  }

  function createSearchIndex(records) {
    return records.map((record) => ({
      code: String(record.code || "").trim(),
      name: String(record.name || "").trim(),
      normalizedCode: normalizeText(record.code).replace(/\s/g, ""),
      normalizedName: normalizeText(record.name),
      compactName: compactText(record.name),
      initials: makeInitials(record.name),
    }));
  }

  function scoreRecord(record, query, compactQuery) {
    if (record.normalizedCode === compactQuery) return [0, 0];
    if (record.normalizedCode.startsWith(compactQuery)) return [1, 0];
    if (record.normalizedName.startsWith(query)) return [2, 0];

    const phraseAt = record.normalizedName.indexOf(query);
    if (phraseAt >= 0) return [3, phraseAt];

    const compactAt = record.compactName.indexOf(compactQuery);
    if (compactAt >= 0) return [4, compactAt];

    if (record.initials.startsWith(compactQuery)) return [5, 0];
    return null;
  }

  function searchICD10(index, rawQuery, limit = 50) {
    const query = normalizeText(rawQuery);
    if (!query) return [];
    const compactQuery = query.replace(/\s/g, "");

    return index
      .map((record) => ({
        record,
        score: scoreRecord(record, query, compactQuery),
      }))
      .filter((entry) => entry.score)
      .sort(
        (a, b) =>
          a.score[0] - b.score[0] ||
          a.score[1] - b.score[1] ||
          a.record.code.localeCompare(b.record.code)
      )
      .slice(0, limit)
      .map(({ record }) => ({ code: record.code, name: record.name }));
  }

  return {
    normalizeText,
    compactText,
    makeInitials,
    createSearchIndex,
    searchICD10,
  };
});
