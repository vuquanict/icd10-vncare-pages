(function () {
  const HOST_ID = "vncare-icd10-extension";
  const HELP_TEXT =
    "Smart Search: hỗ trợ mã ICD (`F00`), có dấu (`rối loạn`), không dấu (`roi loan`), viết liền (`roiloan`) hoặc viết tắt (`rltk`).";

  if (document.getElementById(HOST_ID)) return;

  const host = document.createElement("div");
  host.id = HOST_ID;
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode: "open" });
  const style = document.createElement("style");
  style.textContent = `
    :host {
      all: initial;
    }

    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }

    .launcher,
    .panel {
      font-family: Arial, "Helvetica Neue", sans-serif;
      z-index: 2147483647;
    }

    .launcher {
      position: fixed;
      right: 20px;
      bottom: 20px;
      width: 62px;
      height: 62px;
      padding: 0;
      border: 0;
      border-radius: 50%;
      background: #0b67c2;
      color: #fff;
      font-size: 13px;
      font-weight: 700;
      letter-spacing: .2px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, .28);
      cursor: pointer;
    }

    .launcher:hover {
      background: #09579f;
    }

    .launcher:focus-visible,
    input:focus-visible,
    .close:focus-visible {
      outline: 3px solid #79b8ff;
      outline-offset: 2px;
    }

    .panel {
      position: fixed;
      right: 20px;
      bottom: 94px;
      width: min(420px, calc(100vw - 24px));
      max-height: min(560px, calc(100vh - 120px));
      display: flex;
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #d8e1eb;
      border-radius: 14px;
      background: #fff;
      color: #1d2939;
      box-shadow: 0 14px 40px rgba(0, 0, 0, .25);
    }

    .panel[hidden] {
      display: none;
    }

    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 16px;
      background: #0b67c2;
      color: #fff;
    }

    .title {
      margin: 0;
      font-size: 17px;
      font-weight: 700;
    }

    .close {
      width: 32px;
      height: 32px;
      padding: 0;
      border: 0;
      border-radius: 8px;
      background: transparent;
      color: #fff;
      font-size: 25px;
      line-height: 32px;
      cursor: pointer;
    }

    .close:hover {
      background: rgba(255, 255, 255, .16);
    }

    .search-wrap {
      padding: 14px 16px 10px;
    }

    input {
      width: 100%;
      padding: 11px 12px;
      border: 1px solid #aebdca;
      border-radius: 9px;
      background: #fff;
      color: #17202a;
      font: 15px Arial, sans-serif;
    }

    input::placeholder {
      color: #7b8794;
    }

    .status {
      padding: 8px 16px 14px;
      color: #667085;
      font-size: 13px;
      line-height: 1.4;
    }

    .results {
      margin: 0;
      padding: 0;
      overflow-y: auto;
      list-style: none;
      overscroll-behavior: contain;
    }

    .result {
      padding: 11px 16px;
      border-top: 1px solid #edf1f5;
    }

    .result:hover {
      background: #f6f9fc;
    }

    .code {
      display: block;
      color: #075da9;
      font-size: 14px;
      font-weight: 700;
    }

    .name {
      display: block;
      margin-top: 3px;
      color: #344054;
      font-size: 14px;
      line-height: 1.4;
    }

    .credit {
      flex: 0 0 auto;
      padding: 7px 16px 9px;
      border-top: 1px solid #edf1f5;
      color: #98a2b3;
      font-size: 11px;
      font-style: italic;
      text-align: right;
    }

    @media (max-width: 520px) {
      .launcher {
        right: 12px;
        bottom: 12px;
      }

      .panel {
        right: 12px;
        bottom: 86px;
      }
    }
  `;

  const launcher = document.createElement("button");
  launcher.className = "launcher";
  launcher.type = "button";
  launcher.textContent = "ICD10";
  launcher.setAttribute("aria-label", "Mở tra cứu ICD-10");
  launcher.setAttribute("aria-expanded", "false");

  const panel = document.createElement("section");
  panel.className = "panel";
  panel.hidden = true;
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", "Tra cứu ICD-10");

  const header = document.createElement("header");
  header.className = "header";

  const title = document.createElement("h2");
  title.className = "title";
  title.textContent = "Tra cứu ICD-10";

  const close = document.createElement("button");
  close.className = "close";
  close.type = "button";
  close.textContent = "×";
  close.setAttribute("aria-label", "Đóng");
  header.append(title, close);

  const searchWrap = document.createElement("div");
  searchWrap.className = "search-wrap";

  const input = document.createElement("input");
  input.type = "search";
  input.placeholder = "Nhập mã hoặc tên bệnh...";
  input.autocomplete = "off";
  input.spellcheck = false;
  searchWrap.appendChild(input);

  const status = document.createElement("div");
  status.className = "status";
  status.setAttribute("aria-live", "polite");
  status.textContent = HELP_TEXT;

  const results = document.createElement("ul");
  results.className = "results";

  const credit = document.createElement("div");
  credit.className = "credit";
  credit.textContent = "by Nguyễn Vũ Quân - Tổ CNTT";

  panel.append(header, searchWrap, status, results, credit);
  shadow.append(style, launcher, panel);

  let index = null;
  let loadingPromise = null;
  let debounceTimer = null;
  let queryVersion = 0;

  function setStatus(message) {
    status.textContent = message;
  }

  function renderResults(items) {
    results.replaceChildren();

    if (!items.length) {
      setStatus("Không tìm thấy kết quả phù hợp.");
      return;
    }

    setStatus(`Hiển thị ${items.length} kết quả.`);
    const fragment = document.createDocumentFragment();

    for (const item of items) {
      const row = document.createElement("li");
      row.className = "result";

      const code = document.createElement("span");
      code.className = "code";
      code.textContent = item.code;

      const name = document.createElement("span");
      name.className = "name";
      name.textContent = item.name;

      row.append(code, name);
      fragment.appendChild(row);
    }

    results.appendChild(fragment);
  }

  async function ensureData() {
    if (index) return index;

    if (!loadingPromise) {
      setStatus("Đang tải dữ liệu ICD-10...");
      loadingPromise = fetch(chrome.runtime.getURL("data/icd10.json"))
        .then((response) => {
          if (!response.ok) throw new Error(`HTTP ${response.status}`);
          return response.json();
        })
        .then((records) => {
          index = ICD10Search.createSearchIndex(records);
          return index;
        })
        .catch((error) => {
          loadingPromise = null;
          setStatus("Không thể tải dữ liệu ICD-10.");
          console.error("[ICD10]", error);
          throw error;
        });
    }

    return loadingPromise;
  }

  async function runSearch(version) {
    const query = input.value.trim();

    if (!query) {
      results.replaceChildren();
      setStatus(HELP_TEXT);
      return;
    }

    try {
      const searchIndex = await ensureData();
      if (version !== queryVersion) return;
      const items = ICD10Search.searchICD10(searchIndex, query, 50);
      renderResults(items);
    } catch {
      results.replaceChildren();
    }
  }

  async function openPanel() {
    panel.hidden = false;
    launcher.setAttribute("aria-expanded", "true");
    input.focus();

    try {
      await ensureData();
      if (!input.value.trim()) setStatus(HELP_TEXT);
    } catch {
      // ensureData already displays the load error.
    }
  }

  function closePanel() {
    panel.hidden = true;
    launcher.setAttribute("aria-expanded", "false");
    launcher.focus();
  }

  launcher.addEventListener("click", () => {
    if (panel.hidden) openPanel();
    else closePanel();
  });

  close.addEventListener("click", closePanel);

  input.addEventListener("input", () => {
    clearTimeout(debounceTimer);
    queryVersion += 1;
    const version = queryVersion;
    debounceTimer = setTimeout(() => runSearch(version), 120);
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !panel.hidden) closePanel();
  });
})();
